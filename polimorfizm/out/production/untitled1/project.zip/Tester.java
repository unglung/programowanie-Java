public class Tester extends User{
    @Override
    String getAccessLevel() {
        return "Test environment access";
    }
}
