abstract class User {
    abstract String getAccessLevel();
}
