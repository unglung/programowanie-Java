public class Programmer extends User {
    @Override
    String getAccessLevel() {
        return "Code access";
    }
}
